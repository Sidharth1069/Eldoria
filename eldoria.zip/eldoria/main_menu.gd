extends Control

@onready var first_bg: TextureRect = $BackgroundImage
@onready var next_bg: TextureRect = $NextBackground

var images: Array[String] = []
var current_index: int = 0

func _ready():
	first_bg.modulate = Color.WHITE
	next_bg.modulate = Color.WHITE
	next_bg.modulate.a = 0.0
	next_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE

	find_images("res://Eldoria/assets/image/background")
	images.sort()

	print("Images found: ", images.size())

	if images.size() > 0:
		first_bg.texture = load(images[0])
		current_index = 1
		play_slideshow()
	else:
		push_warning("No background images found!")

func find_images(folder_path: String):
	var dir = DirAccess.open(folder_path)

	if dir == null:
		push_warning("Folder not found: " + folder_path)
		return

	dir.list_dir_begin()
	var file_name = dir.get_next()

	while file_name != "":
		var full_path = folder_path.path_join(file_name)

		if dir.current_is_dir():
			if not file_name.begins_with("."):
				find_images(full_path)
		else:
			var extension = file_name.get_extension().to_lower()

			if extension in ["png", "jpg", "jpeg", "webp"]:
				images.append(full_path)

		file_name = dir.get_next()

	dir.list_dir_end()

func play_slideshow():
	while images.size() > 1:
		await get_tree().create_timer(6.5).timeout

		next_bg.texture = load(images[current_index])
		next_bg.modulate.a = 0.0

		var fade = create_tween()
		fade.tween_property(next_bg, "modulate:a", 1.0, 1.5)

		await fade.finished

		first_bg.texture = next_bg.texture
		next_bg.modulate.a = 0.0

		current_index = (current_index + 1) % images.size()
